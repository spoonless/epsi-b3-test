package fr.epsi.b3.geometrie;

public class GeometrieException extends Exception {

	public GeometrieException() {
		super();
	}

	public GeometrieException(String message) {
		super(message);
	}

}

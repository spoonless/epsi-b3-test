package fr.epsi.b3.geometrie;

public class LongueurLargeurInvalideException extends GeometrieException{

	public LongueurLargeurInvalideException(String message) {
		super(message);
	}

}

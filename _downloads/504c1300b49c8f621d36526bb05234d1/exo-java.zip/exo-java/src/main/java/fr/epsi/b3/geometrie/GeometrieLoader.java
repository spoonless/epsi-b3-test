package fr.epsi.b3.geometrie;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.List;

public class GeometrieLoader {
	
	public Geometrie chargerGeometrie(String fichier) throws IOException, GeometrieException {
		Geometrie geometrie = new Geometrie();
		File file = new File(fichier);
		List<String> lines = Files.readAllLines(file.toPath(), Charset.forName("utf-8"));
		for(String ligne : lines) {
			String[] colonnes = ligne.split(";");
			ajouter(geometrie, colonnes);
		}
		return geometrie;
	}

	private void ajouter(Geometrie geometrie, String[] colonnes) throws GeometrieException {
		if ("RECTANGLE".equals(colonnes[0])) {
			Rectangle rectangle = new Rectangle(Double.valueOf(colonnes[1]), Double.valueOf(colonnes[2]));
			geometrie.ajouter(rectangle);
		} else if ("DISQUE".equals(colonnes[0])) {
			Disque disque = new Disque(Double.valueOf(colonnes[1]));
			geometrie.ajouter(disque);
		}
	}

}

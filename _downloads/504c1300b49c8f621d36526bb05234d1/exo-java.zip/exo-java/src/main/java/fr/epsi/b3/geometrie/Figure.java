package fr.epsi.b3.geometrie;

public abstract class Figure {

	public abstract double getAire();
	
	public abstract double getPerimetre();
}

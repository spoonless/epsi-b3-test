package io.github.spoonless.selenium;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DuckDuckGoReferencementAcceptanceTest {

	private WebDriver webDriver;

	@Before
	public void createWebDriver() {
		webDriver = new ChromeDriver();
	}

	@After
	public void closeWebDriver() {
		webDriver.quit();
	}

	@Test
	public void checkSeleniumDevSiteFoundInFirstPageOfDuckduckgo() throws Exception {
		webDriver.navigate().to("https://duckduckgo.com/");
		WebElement searchInput = webDriver.findElement(By.name("q"));
		WebElement searchButton = webDriver.findElement(By.id("search_button_homepage"));

		searchInput.sendKeys("selenium");
		searchButton.click();

		List<WebElement> resultLinks = webDriver.findElements(By.partialLinkText("https://www.selenium.dev"));
		assertFalse("Aucun lien trouvé pour selenium.dev", resultLinks.isEmpty());
	}

}

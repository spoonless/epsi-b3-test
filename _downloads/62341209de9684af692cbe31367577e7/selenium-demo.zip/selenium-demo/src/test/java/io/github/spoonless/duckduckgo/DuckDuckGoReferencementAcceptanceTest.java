package io.github.spoonless.duckduckgo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DuckDuckGoReferencementAcceptanceTest {

	private WebDriver webDriver;

	@Before
	public void createWebDriver() {
		webDriver = new ChromeDriver();
	}

	@After
	public void closeWebDriver() {
		webDriver.quit();
	}

	@Test
	public void checkSeleniumDevSiteFoundInFirstPageOfDuckduckgo() throws Exception {
		ResultPage resultPage = HomePage.openWith(webDriver)
				                        .enterKeywords("selenium")
				                        .clickOnSearch();

		assertTrue(resultPage.isLinkPresent("https://www.selenium.dev"));
	}

}
